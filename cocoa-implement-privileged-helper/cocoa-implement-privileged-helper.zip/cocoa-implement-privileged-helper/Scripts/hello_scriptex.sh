#!/bin/bash
echo "Hello Scriptex, I am `(/usr/bin/whoami)`"