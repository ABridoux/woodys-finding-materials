import Foundation

struct HelperConstants {
    static let helpersFolder = "/Library/PrivilegedHelperTools/"
    static let domain = "com.abridoux.Scriptex.helper"
    static let helperPath = helpersFolder + domain
}
