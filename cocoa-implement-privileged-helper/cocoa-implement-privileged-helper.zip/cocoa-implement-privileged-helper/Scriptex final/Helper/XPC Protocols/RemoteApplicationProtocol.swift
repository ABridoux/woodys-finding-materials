import Foundation

@objc(MainApplicationProtocol)
public protocol RemoteApplicationProtocol {
    // empty protocol but required for the XPC connection
}
