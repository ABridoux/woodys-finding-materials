import Foundation

NSLog("Scriptex Helper started")
let helper = Helper()
helper.run()
